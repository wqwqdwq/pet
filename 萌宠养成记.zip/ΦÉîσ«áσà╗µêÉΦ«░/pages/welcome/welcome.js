Page({
  onTapJump:function(event){      //onTapJump为定义的页面跳转的类名
    wx.redirectTo({               //直接卸载上一个页面并打开跳转页面
      url: '../post/post',        //跳转路径
      success:function(){         //控制台信息反馈函数
        console.log("jump success")
      },
      fail:function(){
        console.log("jump failed")
      },
      complete:function(){
        console.log("jump complete")
      }
    });
  }
})